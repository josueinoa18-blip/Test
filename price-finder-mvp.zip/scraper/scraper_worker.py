# scraper/scraper_worker.py - educativo
import requests, time
from bs4 import BeautifulSoup

HEADERS = {'User-Agent': 'Mozilla/5.0 (compatible; XclusiveBot/1.0)'}

def parse_price(text):
    return float(text.replace('$','').replace(',','').strip())

def scrape_demo(url):
    r = requests.get(url, headers=HEADERS, timeout=10)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, 'html.parser')
    # Este es un demo: busca elementos que parezcan precios
    price_el = soup.select_one('.price') or soup.select_one('.product-price') or soup.select_one('meta[itemprop=price]')
    if price_el is None:
        print('No price found on demo page')
        return None
    text = price_el.get_text(strip=True)
    try:
        return parse_price(text)
    except:
        return None

if __name__ == '__main__':
    print('Ejecuta esto con URLs reales de tiendas que permitan scraping.')
