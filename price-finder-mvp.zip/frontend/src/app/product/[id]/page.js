'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ProductPage({ params }) {
  const id = params.id;
  const [data, setData] = useState(null);

  useEffect(()=> {
    fetch(`http://localhost:4000/product/${id}`)
      .then(r=>r.json()).then(setData).catch(console.error);
  },[id]);

  if (!data) return <p style={{padding:20}}>Cargando producto…</p>;

  const { product, offers } = data;

  return (
    <div style={{padding:24, fontFamily:'Arial, sans-serif'}}>
      <div style={{maxWidth:900, margin:'0 auto', background:'#fff', padding:20, borderRadius:8}}>
        <div style={{display:'flex', gap:20}}>
          <img src={product.image_url || '/placeholder.png'} alt={product.title} width={180} height={180} style={{borderRadius:8}}/>
          <div>
            <h1 style={{fontSize:24}}>{product.title}</h1>
            <p style={{color:'#666'}}>{product.brand}</p>
            <p style={{marginTop:8}}>{product.description}</p>
          </div>
        </div>

        <h3 style={{marginTop:16}}>Ofertas</h3>
        <div>
          {offers.map(o => (
            <div key={o.id} style={{display:'flex', justifyContent:'space-between', padding:12, borderRadius:8, border:'1px solid #eee', marginBottom:8}}>
              <div>
                <div style={{fontWeight:700}}>{o.store_name}</div>
                <div style={{color:'#666'}}>{o.url}</div>
              </div>
              <div style={{textAlign:'right'}}>
                <div style={{color:'#666'}}>Tienda</div>
                <div style={{fontWeight:700, fontSize:20}}>${( +o.price + +o.shipping ).toFixed(2)}</div>
                <button onClick={()=> {
                  const cart = JSON.parse(localStorage.getItem('cart')||'[]');
                  cart.push({offerId: o.id, title: product.title + ' - ' + o.store_name, unit_amount_cents: Math.round((+o.price + +o.shipping)*100), quantity:1});
                  localStorage.setItem('cart', JSON.stringify(cart));
                  alert('Añadido al carrito');
                }} style={{marginTop:8, padding:'8px 10px', background:'#111', color:'#fff', borderRadius:6}}>Añadir al carrito</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
