'use client';
import { useState } from 'react';

export default function AdminPage() {
  const [form, setForm] = useState({product_id:1, store_name:'', price:'', shipping:'', url:''});
  async function submit(e) {
    e.preventDefault();
    const res = await fetch('http://localhost:4000/admin/offers', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(form)});
    const data = await res.json();
    alert('Oferta creada: ' + JSON.stringify(data));
  }
  return (
    <div style={{padding:24, fontFamily:'Arial, sans-serif'}}>
      <h1>Admin</h1>
      <form onSubmit={submit} style={{maxWidth:600, background:'#fff', padding:16, borderRadius:8}}>
        <label>Product ID: <input value={form.product_id} onChange={e=>setForm({...form, product_id: parseInt(e.target.value)})} /></label><br/>
        <label>Store name: <input value={form.store_name} onChange={e=>setForm({...form, store_name:e.target.value})} /></label><br/>
        <label>Price: <input value={form.price} onChange={e=>setForm({...form, price:e.target.value})} /></label><br/>
        <label>Shipping: <input value={form.shipping} onChange={e=>setForm({...form, shipping:e.target.value})} /></label><br/>
        <label>URL: <input value={form.url} onChange={e=>setForm({...form, url:e.target.value})} /></label><br/>
        <button style={{marginTop:8}}>Crear oferta</button>
      </form>
    </div>
  );
}
