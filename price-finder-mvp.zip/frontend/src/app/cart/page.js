'use client';
import { useState, useEffect } from 'react';

export default function CartPage() {
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(()=> {
    setCart(JSON.parse(localStorage.getItem('cart')||'[]'));
  },[]);

  function remove(i) {
    const c = [...cart]; c.splice(i,1); setCart(c); localStorage.setItem('cart', JSON.stringify(c));
  }

  async function checkout() {
    setLoading(true);
    const items = cart.map(c=>({ title: c.title, unit_amount_cents: c.unit_amount_cents, quantity: c.quantity }));
    const res = await fetch('http://localhost:4000/create-checkout-session', {
      method:'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({
        items,
        success_url: 'http://localhost:3000/checkout-success',
        cancel_url: 'http://localhost:3000/cart'
      })
    });
    const data = await res.json();
    const stripe = await (await import('@stripe/stripe-js')).loadStripe('pk_test_XXXX');
    await stripe.redirectToCheckout({ sessionId: data.id });
    setLoading(false);
  }

  const total = cart.reduce((s,i) => s + (i.unit_amount_cents/100)*i.quantity, 0).toFixed(2);

  return (
    <div style={{padding:24, fontFamily:'Arial, sans-serif'}}>
      <div style={{maxWidth:800, margin:'0 auto', background:'#fff', padding:20, borderRadius:8}}>
        <h1>Carrito</h1>
        <div style={{marginTop:12}}>
          {cart.map((c, idx) => (
            <div key={idx} style={{display:'flex', justifyContent:'space-between', marginBottom:8}}>
              <div>{c.title} x {c.quantity}</div>
              <div>${((c.unit_amount_cents/100)*c.quantity).toFixed(2)} <button onClick={()=>remove(idx)} style={{marginLeft:8,color:'#e11'}}>X</button></div>
            </div>
          ))}
        </div>
        <div style={{textAlign:'right', marginTop:12}}>
          <div style={{fontWeight:700}}>Total: ${total}</div>
          <button disabled={cart.length===0 || loading} onClick={checkout} style={{marginTop:8, padding:'8px 12px', background:'#059669', color:'#fff', borderRadius:6}}>Pagar con Stripe</button>
        </div>
      </div>
    </div>
  );
}
