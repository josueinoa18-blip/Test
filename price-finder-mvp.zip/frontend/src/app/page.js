'use client';
import { useState } from 'react';
import Link from 'next/link';

export default function Home() {
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);

  async function search() {
    if (!q.trim()) return;
    setLoading(true);
    const res = await fetch(`http://localhost:4000/search?q=${encodeURIComponent(q)}`);
    const data = await res.json();
    setResults(data);
    setLoading(false);
  }

  return (
    <div style={{fontFamily: 'Arial, sans-serif', padding: 24}}>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1>Xclusive Price Finder</h1>
        <nav>
          <a href="/admin" style={{marginRight:12}}>Admin</a>
          <a href="/cart">Carrito</a>
        </nav>
      </header>

      <section style={{marginTop:20, background:'#fff', padding:16, borderRadius:8}}>
        <div style={{display:'flex', gap:8}}>
          <input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=> e.key==='Enter' && search()} placeholder="Buscar producto: ej. Nike Air Zoom" style={{flex:1, padding:10}}/>
          <button onClick={search} style={{padding:'10px 16px'}}>Buscar</button>
        </div>
        {loading && <p>Buscando…</p>}
      </section>

      <section style={{marginTop:16}}>
        {results.map(prod => (
          <div key={prod.id} style={{background:'#fff', padding:12, borderRadius:8, marginBottom:12, display:'flex', justifyContent:'space-between'}}>
            <div>
              <div style={{fontWeight:700}}>{prod.title}</div>
              <div style={{color:'#666'}}>{prod.brand}</div>
              <div style={{color:'#666'}}>{prod.offers.length} ofertas</div>
            </div>
            <div style={{textAlign:'right'}}>
              {prod.offers.length>0 && <>
                <div style={{fontSize:12}}>Mejor:</div>
                <div style={{fontWeight:700, fontSize:20, color:'#10a37f'}}>${prod.offers[0].sellPrice}</div>
                <a href={`/product/${prod.id}`} style={{display:'inline-block', marginTop:8, background:'#1d4ed8', color:'#fff', padding:'6px 10px', borderRadius:6}}>Ver</a>
              </>}
            </div>
          </div>
        ))}
        {results.length===0 && !loading && <p style={{color:'#666'}}>Escribe un producto para buscar.</p>}
      </section>
    </div>
  );
}
