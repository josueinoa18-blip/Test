// backend/server.js
const express = require('express');
const app = express();
app.use(express.json());
const PORT = process.env.PORT || 4000;

// For demo purposes: use in-memory DB if no Postgres configured
const usePg = !!process.env.DATABASE_URL;
let pool = null;
if (usePg) {
  const { Pool } = require('pg');
  pool = new Pool({ connectionString: process.env.DATABASE_URL });
} else {
  console.log('No DATABASE_URL detected. Backend will run with in-memory demo data.');
}

// Stripe
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_XXXX');

// Fee util
function applyFee(price) {
  const pct = 0.08;
  const min = 2.0;
  return +(price + Math.max(price * pct, min)).toFixed(2);
}

// Demo in-memory data
const demoProducts = [
  { id: 1, slug: 'nike-air-zoom-001', title: 'Nike Air Zoom', brand: 'Nike', description: 'Zapatillas running', image_url: '' }
];
const demoOffers = [
  { id: 1, product_id: 1, store_name: 'StoreA', price: 120.00, shipping: 5.00, url: 'https://storea.example/product/1' },
  { id: 2, product_id: 1, store_name: 'StoreB', price: 115.00, shipping: 15.00, url: 'https://storeb.example/product/2' },
  { id: 3, product_id: 1, store_name: 'MarketplaceX', price: 118.00, shipping: 0.00, url: 'https://market.example/item/3' }
];

app.get('/search', async (req, res) => {
  const q = (req.query.q || '').trim().toLowerCase();
  if (!q) return res.json([]);
  if (!usePg) {
    const found = demoProducts.filter(p => p.title.toLowerCase().includes(q) || p.slug.includes(q));
    const prods = found.map(p => {
      const offers = demoOffers.filter(o => o.product_id === p.id).map(o => {
        const total = +(o.price + o.shipping).toFixed(2);
        return {...o, total, sellPrice: applyFee(total)};
      }).sort((a,b) => a.sellPrice - b.sellPrice);
      return {...p, offers};
    });
    return res.json(prods);
  } else {
    // Implement Postgres-backed search (omitted for brevity)
    return res.json([]);
  }
});

app.get('/product/:id', async (req,res) => {
  const id = parseInt(req.params.id);
  if (!usePg) {
    const p = demoProducts.find(x => x.id === id);
    if (!p) return res.status(404).json({error:'Not found'});
    const offers = demoOffers.filter(o => o.product_id === id).map(o => ({...o, history: [{price: o.price, shipping: o.shipping, checked_at: new Date()}]}));
    return res.json({product: p, offers});
  } else {
    // Postgres-backed (omitted)
    return res.json({});
  }
});

// Admin add offer (no auth in demo)
app.post('/admin/offers', async (req,res) => {
  const { product_id, store_name, price, shipping, url } = req.body;
  if (!usePg) {
    const id = demoOffers.length + 1;
    const o = { id, product_id, store_name, price: +price, shipping: +shipping, url };
    demoOffers.push(o);
    return res.json(o);
  } else {
    // insert into Postgres
    return res.json({});
  }
});

// Create Stripe Checkout session
app.post('/create-checkout-session', async (req,res) => {
  try {
    const { items, success_url, cancel_url } = req.body;
    const line_items = items.map(i => ({
      price_data: {
        currency: 'usd',
        product_data: { name: i.title },
        unit_amount: i.unit_amount_cents,
      },
      quantity: i.quantity
    }));
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items,
      mode: 'payment',
      success_url: success_url || 'http://localhost:3000/checkout-success',
      cancel_url: cancel_url || 'http://localhost:3000/cart',
    });
    res.json({ id: session.id });
  } catch(err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/', (req,res) => res.send('Xclusive Price Finder API (demo)'));

app.listen(PORT, () => console.log(`API en http://localhost:${PORT}`));
